package computer_programing_05;

public class BoxTest {

	public static void main(String[] args) {
		Box myBox = new Box();
		myBox.setWidth(10);
		myBox.setLength(20);
		myBox.setHeight(50);
		
		myBox.print();
	}

}
