package computer_programing_05;

public class Employee {
		private String name;
		private String pn;
		private int ai;
		
		public String getName(){
			return name;
		}
		public void setName(String n){
			name = n;
		}
		public String getPn(){
			return pn;
		}
		public void setPn(String p){
			pn = p;
		}
		public int getAi(){
			return ai;
		}
		public void setAi(int a){
			ai = a;
		}

}
