package computer_programing_06;
public class AccountTest {
	public static void main(String[] args) {
		Account Myaccount = new Account();
		Myaccount.account();
		Myaccount.login();
	}
}